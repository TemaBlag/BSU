#pragma once

#ifdef KEYLOGGERDLL_EXPORTS
#define KEYLOGGERDLL_API __declspec(dllexport)
#else
#define KEYLOGGERDLL_API __declspec(dllimport)
#endif

extern "C" {
    KEYLOGGERDLL_API BOOL StartKeylogger();
    KEYLOGGERDLL_API BOOL StopKeylogger();
}